# run_aurora.ps1
powershell -ExecutionPolicy Bypass -File "$PSScriptRoot\etl_aurora.ps1"
