# run_cams.ps1
powershell -ExecutionPolicy Bypass -File "$PSScriptRoot\etl_cams.ps1"
