# run_all_benchmarks.ps1
powershell -ExecutionPolicy Bypass -File "$PSScriptRoot\run_all_providers.ps1"
