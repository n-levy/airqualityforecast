powershell -ExecutionPolicy Bypass -File .\setup_stage3.ps1
